package bg.sofia.uni.fmi.mjt.auth.domain.users;

public class UnauthenticatedUser extends User {
	UnauthenticatedUser() {
		super();
	}
}
