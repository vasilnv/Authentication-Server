package bg.sofia.uni.fmi.mjt.auth.domain.users;

import java.util.UUID;

public class User {
	private String userID;

	public User() {
		userID = UUID.class.toString();
	}
	public String getID() {
		return this.userID;
	}

}
