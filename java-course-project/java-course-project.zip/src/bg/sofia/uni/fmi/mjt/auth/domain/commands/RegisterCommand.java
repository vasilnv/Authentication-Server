package bg.sofia.uni.fmi.mjt.auth.domain.commands;

public class RegisterCommand implements CommandOperation{

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
