package bg.sofia.uni.fmi.mjt.auth.domain.users;

public class Admin extends AuthenticatedUser{

	public Admin(String username, String pass, String firstName, String lastName, String email) {
		super(username, pass, firstName, lastName, email);
		// TODO Auto-generated constructor stub
	}
}
