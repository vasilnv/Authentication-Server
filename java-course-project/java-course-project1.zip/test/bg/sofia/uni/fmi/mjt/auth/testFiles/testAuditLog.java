package bg.sofia.uni.fmi.mjt.auth.testFiles;

public class testAuditLog {

	@Test
	public void testWritesCorrect() {
		
	}
}
